==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0

   (c) Copyright IBM Corporation 1996, 2019.  All rights reserved. 

Dette dokument stilles til rådighed uden nogen form for garantier.  IBM
fraskriver sig ethvert ansvar, både direkte og indirekte, herunder,
men ikke begrænset til, et produkts salgbarhed eller egnethed til et
bestemt formål, hvad angår oplysningerne i dette dokument. 

===============================================================================

Dette dokument blev sidst opdateret: 04. november, 2019

------------------------------------------------------------------- 

Indhold 

-------------------------------------------------------------------  

1.0 Introduktion
2.0 Placering af oplysningskilder
3.0 Installation
  3.1 Understøttede Windows styresystemer
  3.2 Overvejelser vedr. installation
  3.3 Opgradering fra IBM i Access for Windows
  3.4 Kørsel af installationsprogrammet
  3.5 Handling nødvendig efter installation af printerdriver
  3.6 Overvejelser vedr. 64-bit hardware installation
  3.7 Installationslogfiler
4.0 Krav til IBM.Data.DB2.iSeries .NET Provider
5.0 Microsoft XML Parser eller Microsoft XML Core Services
6.0 Oplysninger om udvidet installation
  6.1 Oplysninger om licensprodukt
  6.2 Sprogfiler på installations-image
  6.3 Installationsfunktioner
  6.4 Kommandolinjeparametre
  6.5 Offentlige egenskaber
  6.6 Brænd et administrations-image til CD eller DVD
7.0 Oplysninger om regler
8.0 Kommandoer der ikke er inkluderet
  


-------------------------------------------------------------------

1.0 Introduktion
-------------------------------------------------------------------
  Denne pakke er en del af 5733XJ1 IBM i Access Client Solutions-produktet

  Du kan anvende IBM i Access Client Solutions til at oprette forbindelse til
  enhver understøttet IBM i release.

  Denne pakke indeholder funktioner, der kun er tilgængelige på Windows styresystemer.  
  Den er baseret på 7.1 IBM i Access til Windows produktet, men indeholder ikke alle
  funktioner.

  Følgende funktioner er inkluderet i denne pakke fra IBM i Access til Windows:
    .NET Data Provider
    ODBC
    OLE DB
    Secure Socket Layer og Certifikatstyring
    Programmer's Toolkit for headers, biblioteker og dokumentation
    AFP-printerdriver
    Påkrævede programmer:
      APIs
      Active X
      Sikkerhed
      Anvendelighed
      Forbindelser
      NLS-aktivering
      Konverteringstabeller
      Egenskaber
      Regler
      Netværksudskrivning
      Subsæt af kommandoer (se afsnit 8.0, hvor der er en liste over, hvad der ikke er inkluderet.)
      Brugerguide
      Brug af Applikationsadministration til adgangskontrol af funktioner i pakken

  Følgende funktioner fra IBM i Access til Windows er ikke inkluderet i denne pakke. 
  
  Den platform-afhængige IBM i Access Client Solution-pakke indeholder en erstatning
  for disse funktioner:
    5250 skærm- og printeremulering
    Dataoverførsel
    Dataoverførsel Excel add-in
    Operations Console
  
  Følgende funktioner fra IBM i Access til Windows er ikke inkluderet i denne pakke. 
    IBM Navigator til i indeholder en erstatning for disse funktioner:
    System i Navigator
    AFP Workbench Viewer

  Indgående ekstern kommando er ikke inkluderet.  Brug i stedet Microsoft
  Remote Desktop Services.

  Toolbox for Java er heller ikke inkluderet.  Anvend følgende web-side for download
  af oplysninger:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Andre funktioner fra IBM i Access til Windows der ikke er inkluderet i denne pakke er:
    SCS printerdriver
    Java Programmer's Tools for System i Navigator plug-ins
    Biblioteksopdatering
    Understøttelse for Lotus 123 filformat
    Kontrollér serviceniveau

  Fordi indholdet af denne pakke også sendes med 7.1 IBM i Access til Windows,
  vil dokumentationen og versioner ofte reflektere 7.1 IBM i Access til Windows i
  Brugerguiden, Programmer's Toolkit, hjælpetekst og meddelelser, men er også
  tilgængelig for IBM i Access Client Solutions - Windows Application Package.


-------------------------------------------------------------------

2.0 Placering af oplysningskilder

-------------------------------------------------------------------

  - Ændringer til IBM i Access Client Solutions inkluderer understøttede styresystemer,
    opdateringer, begrænsninger, kendte problemer, nye oplysninger og mere vil
    blive udgivet på IBM i Access produkt hjemmesiden:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Brugerguiden, der er installeret med denne pakke, indeholder oplysninger om
    brug af produktet, tips og gode råd, meddelelser og  problemløsning.

  - Tekniske referencer til OLE DB provider og .NET Data provider er installeret
    når faciliteten Headers, biblioteker og dokumentation installeres.  Du finder
    tekniske referencer i Programmer's Toolkit folderen.

  - IBM i Information Center tilbyder en samling af emner, der er designet for IBM i
    fagfolk, der har behov for adgang til tekniske oplysninger:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - På tidspunktet for denne publikation, inkluderer IBM i Information Center ikke emner
    om IBM i Access Client Solutions.  Men mange af oplysningerne under IBM i Access
    til Windows er tilgængelig for denne pakke med IBM i Access Client Solutions, inklusive
    emner om installation, administration og programmering:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks indeholder artikler, øvelser samt tekniske ressourcer for
    IBM i bruger:

    https://www.ibm.com/developerworks/ibmi

  - IBM i hjemmesiden indeholder de seneste IBM i-nyheder, foruden produktoplysninger,
    et referencebibliotek, kursus- og uddannelsesvejledninger og meget mere.

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Installation
-------------------------------------------------------------------



3.1 Understøttede Windows styresystemer
---------------------------------------

  Denne pakke kan installeres på følgende Microsoft Windows styresystemer:

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2

   - Windows Server 2008 and Windows Server 2008 R2
         Standard Enterprise (32-bit og 64bit)
   - Windows 7
         Professional, Enterprise, and Ultimate (32-bit og 64-bit)

   Følgende begrænsninger gælder:
 
     a) Home editions er ikke understøttet.
          b) Du skal anvende Windows servicepakke niveauer som Microsoft understøtter.
          c) Understøttelse vil ophøre på den dato, Microsoft ophører med deres understøttelse.
          d) Installation er ikke understøttet på Itanium hardware.
          e) Anvend Microsoft Windows hardware- og hukommelsesanbefalinger. Inkludér
        256 MB ekstra hukommelse til IBM i Access Client Solution-funktioner.
          f) Produktet kan ikke installeres, når der opdateres til et andet Windows styresystem.       Følg disse trin:  Gem alle konfigurationsdata
          2.  Fjern hele produktet.
          3.  Opgradér Windows-styresystemet
          4.  Installér produktet.
          5.  Genindlæs konfigurationsdata.


3.2 Overvejelser vedr. installation
--------------------------------------------------

  - Administrativ autorisation og rettigheder er nødvendige for at køre installation.
  
  - Kun pr. maskine-installationer er understøttet.  Pr. bruger-installationer
    understøttes ikke.

  - Windows Installer 4.5 er påkrævet.  Denne Microsoft softwarekomponent
    installeres under installeringen, hvis den ikke allerede eksisterer på
    systemet.  Du kan installere den før installationen ved at hente den fra Microsoft hjemmesiden:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Opgradering fra IBM i Access for Windows
--------------------------------------------

  -  Opgradering fra IBM i Access til Windows understøttes ikke.  Du skal
     fjerne IBM i Access til Windows, før du installerer denne pakke.  

  -  Se i afsnit 1.0, hvor der en liste over funktioner, der ikke er inkluderet.  
     Hvis du vil beholde funktioner, der er en del af IBM i Access til Windows, men ikke er
     inkluderet i pakken, skal du annullere installationen og fortsætte med at anvende den
     seneste servicepakke til 7.1 IBM i Access til Windows.

  -  Hvis installationen af IBM i Access til Windows fjernes, bliver den eksisterende
     systemkonfigurationen slettet. Hvis du vil bevare den eksisterende
     systemkonfiguration, skal du gemme konfigurationen, inden du installerer
     IBM i Access for Windows, og derefter gendanne konfigurationen, når IBM i
     Access Client Solutions Windows Application Package er installeret. 

     Gør følgende, hvis du vil gemme og gendanne din konfiguration:
     1.  Brug kommandoen CWBBACK til at sikkerhedskopiere konfigurationen med
         IBM i Access til Windows:
             cwbback <filnavn.rs> /u
         Eksempel:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         I dette eksempel antages, at folderen C:\Users\IBM_ADMIN\Backup allerede findes.

         Ovenstående kommando opretter to filer i folderen:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 De to filer skal være oprettet, før du går videre til næste trin.

         Bemærk:
         Hvis ovenstående to filer ikke blev oprettet, har du ikke en gemt
         konfiguration.  Prøv at udføre kommandoen som administrator.
         Start kommandolinjen på følgende måde:
             Start->Alle programmer->Tilbehør->Kommandolinje
         I stedet for at bruge venstreklik på kommandolinjen, skal du bruge
         højreklik og vælge at udføre kommandolinjen som administrator.
         Udfør ovenstående cwbback-kommando med denne kommandolinje.
         De to filer skal være oprettet, før du går videre til næste trin.

     2.  Fjern IBM i Access til Windows.
     3.  Genstart.
     4.  Installér IBM i Access Client Solutions Windows Application Package.
     5.  Genstart.
     6.  Brug kommandoen CWBREST til at genindlæse den konfiguration, der blev
         gemt med kommandoen CWBBACK:
             cwbrest <filnavn.rs> /c
         Eksempel:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Hvis du følger vejledningen under Bemærk i Trin 1, skal du udføre kommandoen
         cwbrest fra en eleveret administratorkommandolinje.

  -  Du kan verificere Windows-konfigurationen før og efter ovenstående trin på flere
     måder:
     1. Undersøg Windows-registret.  Systemkonfigurationer er gemt i:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Skriv følgende kommando for at få vist Windows-registret det pågældende sted:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        Hvis du har et systemmiljø med et andet navn end standardnavnet
        "My Connections", skal du ændre til det korrekte navn i ovenstående sti.

     2. Hvis du har den platformuafhængige version af IBM i Access Client Solutions på den
        samme pc, kan du fra den primære brugergrænseflade vælge:
            Fil->Kopiér forbindelser
        I højre side vises "IBM i Access (Windows)".  Det er den konfiguration, der anvendes
        til både IBM i Access til Windows and til IBM i Access Client Solutions Windows Application
        Package.


3.4 Kørsel af installationsprogrammet
-------------------------------------

  - Kør setup.exe i installationsimaget for at starte installationen.  (Kommandoen
    cwblaunch.exe er ikke med i dette produkt.)
   
      Bemærk:  Direkte kald af Microsoft Installer (MSI) filer anbefales ikke,
             da setup.exe bruger setup.ini for en liste af kommandolinje
             indstillinger, der anvendes til at opdatere Windows Installer
             versionen, hvis det er nødvendigt.
    
  - Det anbefales, at du anvender standarddestinationsmappen.  Hvis du ændrer mappe, skal
     du tage følgende i betragtning:
     
     a) Det frarådes at bruge rodbiblioteket på drevet.
     b) Brug ikke et bibliotek der allerede indeholder filer, der ikke
        er relateret til produktet.
     c) Du bør ikke vælge et netværksdrev.  Installation på et netværksdrev
           understøttes ikke.


3.5 Handling påkrævet efter installation af printerdriver
---------------------------------------------------

  Du skal foretage en handling, før du installerer en printerdriver.    Det skyldes, at printerdriveren ikke er digitalt signeret af Microsoft og ikke kan
  tilføjes eller opdateres automatisk under installationen.  

  Under en installation bliver printerdriverfilerne kopieret
  til et underbibliotek CWBAFP, under den sti der er valgt som destinationssti.    Hvis du har valgt standard destinationsstien, vil stien være:

  c:\Program Files\IBM\Client Access\CWBAFP directory 

  Anvend anvisningerne i hjælpeteksten fra Microsoft til at tilføje eller opdatere
  printerdriveren.
  Når du bliver spurgt, angiv stien til CWBAFP. 

  Hvis du installerer på en pc, der har opgraderet IBM i Access
  til Windows over flere releases, vises der muligvis gamle
  oplysninger, når du konfigurerer printerdriveren.  Du kan fjerne
  de forældede oplysninger fra .inf-filer på følgende måde, når du har
  afsluttet installationen:

    a) Åbn et kommandolinjevindue.
        b) Skift bibliotek til installationsbiblioteket. Standard-
       installationsbiblioteket er c:\Program Files\IBM\Client Access.
        c) Skriv "cwbrminf", og tryk på Enter. 


3.6 Overvejelser vedrørende 64-bit hardwareinstallation
-------------------------------------------------------

  Når du installerer på et understøttet 64-bit Windows styresystem:
  
  -  Både 32-bit versionen og 64-bit versionen installeres for ODBC, OLE DB,
     ActiveX og SSL (Secure Sockets Layer).  

  -  IBM i Access til Windows .NET provider kører fra både 32-bit- og 64-bit-
     applikationer, afhængig af hvilken applikation der kalder.

  -  Kun en version af AFP-printerdriveren bliver installeret.  64-bit versionen
     installeres på 64-bit systemer og 32-bit versionen installeres på 32-bit systemer.


3.7 Installationslogfiler
-------------------------

  Der oprettes to logfiler under installationen. En af logfilerne er specifik for XJ1 og indeholder
  oplysninger om tilpasning af produktet.  Logfilen hedder "xe1instlog.txt"
  og oprettes altid i brugerens temp bibliotek.

  Den anden logfil er Microsofts MSI-log, der indeholder oplysninger om
  MSI-aktiviteter, -sekvenser og egenskaber.  Som standard kaldes denne
  log "xe1instlogmsi.txt" og oprettes i brugerens temp-bibliotek.   Du kan ændre
  loggen ved at redigere setup.ini i installationsimage.  Gå til startnøgleordet,
  og find og redigér denne indgang: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Fjern indgangen, hvis loggen ikke skal oprettes
    - Ret sti- og filnavn for at ændre placering af og navn på loggen
    - Hvis du vil ændre loggens indhold, kan du ændre /l* til en anden parameter,
      som beskrevet i kommandolinjeparametrene til Microsofts MSDN Windows
      Installer i http://msdn.microsoft.com/default.aspx 

      http://msdn.microsoft.com/default.aspx   

  Standard kommandolinje oplysningerne i setup.ini kan overskrives ved at starte
  setup.exe i kommando-promptet med kommandolinje parametre.



-------------------------------------------------------------------

4.0 Krav til IBM.Data.DB2.iSeries .NET Provider 

-------------------------------------------------------------------

  - IBM i Access til Windows .NET Data Provider (IBM.Data.DB2.iSeries)
    kræver, at Microsofts .NET Framework installeres på systemet.      De fleste pc'er, der understøtter Microsoft styresystemer,
    har allerede den påkrævede .NET Framework installeret.      .NET Framework kan overføres fra Microsofts websted på adressen: 

    http://www.microsoft.com/net 

  - For at undgå sammenbrud i .NET-applikationer skal
    runtimeforespørgsler for versionen 10.0.0.0 af .NET-udbyderen
    omdirigeres til  den nye 12.0.0.0 version.  Der er oplysninger i emnet
   "Incompatible changes from 5.3 and 5.4" i IBM DB2 til i .NET Provider Technical
    Reference med instruktioner om, hvordan filerne app.config, web.config eller
    machine.config bruges eller om valg af den relevante compiler til omdirigering
    af eksisterende applikationer.

    Alternativt kan applikationen kompileres igen ved at anvende en nyere compiler
    for at bruge 12.0.0.0-versionen af den .NET-udbyder, der følger med IBM i Access til Windows 7.1.

  - En fuldstændig liste over inkompatible ændringer kan du få vist ved at
    installere headere, biblioteker og dokumentation og derefter få vist .NET Provider
    Technical Reference. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser eller Microsoft XML Core Services

-------------------------------------------------------------------

  Når du anvender IBM i Access til Windows Dataoverførsel ActiveX-automationsobjekter til
  at overføre filer til og fra Excel XML format (understøttet af Excel 2003 og
  Excel XP), skal der installeres yderligere software på pc'en. Denne støtte kræver,
  at Microsoft XML Parser 3.0 eller nyere, også kaldet Microsoft XML Core Services,
  er installeret på din pc. XML Parser er medtaget i mange Microsoft-produkter.    Du kan finde ud af, om  XML Parser-support er installeret på pc-en ved at se i Microsoft
  KB article 278674.  Denne artikel findes på Microsofts websted:

  http://support.microsoft.com/kb/278674

  Hvis Microsoft XML Parser 3.0 eller nyere ikke er fundet, skal du gå til
  Microsofts web for at oplysninger om download og installation af XML Parser, før du
  kan bruge Data Transfer XML-support.  Se i Microsoft KB article 324460
  for at få oplysninger om installation af XML Parser.  Denne artikel findes på
  Microsofts websted :

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Oplysninger om udvidet installation

-------------------------------------------------------------------

  - Yderligere oplysninger om ændring af niveau for brugergrænseflade vha.
    kommandolinjeparametre og styring af andre installationsmiljøer er
    tilgængelige under emnet "Setting up the PC" i IBM i Information Center for
    IBM i Access til Windows.  Forskellene er beskrevet i dette afsnit.


6.1 Oplysninger om licensprodukt
----------------------------------
  
  5733XJ1 er ikke pakket som et licensprodukt, der skal installeres på IBM i styresystemet.
  Det er kun tilgængeligt på et pc-medie. Efter behov kan du kopiere det til en placering på IBM i,
  der er tilgængelig for dine brugere.
  

6.2 Sprogfiler på installations-image
--------------------------------------------
  
  Installationsfilerne til sprog, er ikke længere adskilt i et andet MRI29xx bibliotek
  på installationsmediet. I stedet er der forskellige cab-filer for hvert sprog.  Du kan
  ikke fjerne disse cab filer fra mediet.


6.3 Installationsfunktioner
-------------------------------

  Nogle installationsfunktioner i IBM i Access til Windows, er afhængige af
  at andre funktioner er installeret.  Dette gælder ikke for denne pakke.

  Følgende installationsfunktioner er påkrævede at installere:
    req (Required Programs)
    langacs, amri2924 (English)

  Alle andre installationsfunktioner installeres som standard, men du kan ændre indstillingerne.

  Sprog er nu installationsfunktioner, ligesom Required Programs, ODBC, osv. Når
  sprog er installationsfunktioner, kan du vælge hvilke sprog, der skal installeres,
  på samme måde som med andre installationsfunktioner.  Navnet på installationsfaciliteten for
  sprog er amri29xx.  


6.4 Kommandolinjeparametre
------------------------

  Standard kommandolinjeparametrene er angivet i setup.ini filen, der er inkluderet på
  installations-mediet.  Disse parametre vil blive ignoreret, hvis du starter setup.exe fra
  kommandolinjen med andre parametre angivet.  

  Hvis du anvender transformation fra kommandolinjen, vil kommonadolinjeværdierne i setup.ini
  blive ignoreret, da transform er en parameter.  Du skal inkludere andre parametre
  på kommandolinjen, såsom logregistrering.

  Se afsnit 3.7, hvor der er flere oplysninger om Installationslogfiler.


6.5 Offentlige egenskaber
---------------------

  Nogle af IBM i Access til Windows offentlige egenskaber er tilgængelige for denne pakke.  Anvendelsen
  er lidt forskellig fra anvendelsen i IBM i Access til Windows, som det er beskrevet her:

  CWBINSTALLTYPE   Denne egenskab anvendes, kun første gang der installeres.  De eneste værdier
                   er Typical og Custom.  Standardværdien er Typical.
                   Eksempel: setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   Standard primært sprog er sprogkonventionen på din pc.  Denne egenskab giver
                   mulighed for at angive et andet primært sprog. Værdien, der skal anvendes, er MRI29xx. 
                   Eksempel: setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   Anvendelsen af denne egenskab, er den samme som for IBM i Access til Windows.  Den giver
                   mulighed for, at opgradere SSL-filerne under en opgradering.  Hvis konfigurationsfilerne for
                   SSL findes på destinations-pc'en, vil filerne blive opdateret med de seneste certifikater.                     Værdierne er Yes og No. Standard er Yes.
                   Eksempel: setup /vCWBUPGSSLFILES=NO

  De almindelige Windows Installer-egenskaber, der er angivet i emnet i IBM i Access til Windows Information
  Center, er stadig tilgængelige: ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  Der er begrænsninger ved brug af REBOOT Windows Installer-egenskaben med IBM i Access
  ftilor Windows.  Denne begrænsning gælder ikke for denne pakke.
  

6.6 Brænd administrations-image til CD eller DVD
------------------------------------------------

  På grund af problemer med, hvordan noget software til brænding af cd'er og dvd'er
  håndterer lange filnavne, frarådes det at brænde et administrativt image til en cd
  eller dvd. Hvis du støder på problemer ved installation fra en cd eller dvd, der
 indeholder et administrativt image til IBM i Access til Windows, kan du kopiere det
 til den lokale harddisk og køre setup.exe fra den lokale kopi.

-------------------------------------------------------------------
7.0 Oplysninger om regler
-------------------------------------------------------------------

  De samme regelfiler bruges for både denne pakke og IBM i Access til Windows. Det
  betyder at nogle regler ikke er tilgængelige, når de anvendes med denne pakke,
  da nogle af funktionerne ikke eksisterer i denne pakke.

-------------------------------------------------------------------

8.0 Kommandoer
-------------------------------------------------------------------

  Kommandoer i IBM i Access til Windows der ikke er inkluderet i denne pakke:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[Slut på dokument]
