==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0

   (c) Copyright IBM Corporation 1996, 2019.  All rights reserved. 


==============================================================================
  本文档是“按现状”提供的，不附有任何种类的（无论是明示的还是
  暗含的）保证。IBM 免除所有保证，包括但不限于暗含的有关非侵权、
  适销和适用于某种特定用途的保证。提供本文档并不表示 IBM 授予
  用户使用这些专利或版权的任何许可。


===============================================================================

本文档最近一次更新日期：2019 年 11 月 4 日

------------------------------------------------------------------- 

目录

-------------------------------------------------------------------  

1.0 简介
2.0 信息源的位置
3.0 安装
  3.1 受支持的 Windows 操作系统
  3.2 安装注意事项
  3.3 从 IBM i Access for Windows 进行升级
  3.4 运行安装
  3.5 安装打印机驱动程序之后需要执行的操作
  3.6 64 位硬件安装注意事项
  3.7 安装日志
4.0 IBM.Data.DB2.iSeries .NET 提供程序要求
5.0 Microsoft XML Parser 或 Microsoft XML Core Services
6.0 高级安装信息
  6.1 许可产品信息
  6.2 安装映像中的语言文件
  6.3 安装功能部件
  6.4 命令行选项
  6.5 公共属性
  6.6 将管理映像刻录至 CD 或 DVD
7.0 策略信息
8.0 未包括的命令
  


-------------------------------------------------------------------

1.0 简介
-------------------------------------------------------------------
  此程序包是 5733XJ1 IBM i Access Client Solutions 产品的一部分。

  可使用 IBM i Access Client Solutions 来连接至任何受支持的 IBM i 发行版。

  此程序包包含仅在 Windows 操作系统上可用的函数。它基于 7.1 IBM i Access for Windows 产品，
  但没有包含所有功能部件。

  以下是此程序包中包括的源自 IBM i Access for Windows 的功能部件:
    .NET 数据提供程序
    ODBC
    OLE DB
    安全套接字层和证书管理
    程序员工具箱（针对头、库和文档）
    AFP 打印机驱动程序
    包括下列必需程序：
      API
      Active X
      安全性
      可维护性
      连接
      NLS 支持
      转换表
      属性
      策略
      网络打印
      命令子集（请参阅 8.0 这一节以获取未包括的命令的列表。）
      用户指南
      使用应用程序管理来控制对该程序包中函数的访问

  此程序包中未包括源自 IBM i Access for Windows 的下列功能部件。
  IBM i Access Client Solution 与平台无关的软件包包括以下功能部件
  的替代：
    5250 显示器和打印机仿真
    数据传输
    数据传输 Excel 加载宏
    操作控制台

  此程序包中未包括源自 IBM i Access for Windows 的下列功能部件。
  IBM Navigator for i 包括对下列功能部件的替代：
    System i 导航器
    AFP 工作台查看器

  未包括入局远程命令。替代方法是使用 Microsoft 的 Remote Desktop Services。

  也未包括 Toolbox for Java。请使用以下 Web 站点来下载信息：

  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  以下是此程序包中未包括的源自 IBM i Access for Windows 的其他功能部件：
    SCS 打印机驱动程序
    Java 程序员工具（针对 System i 导航器插件）
    目录更新
    Lotus 123 文件格式支持
    检查服务级别

  由于此程序包的内容还附带交付 7.1 IBM i Access for Windows，因此文档和版本控制通常反映
  7.1 IBM i Access for Windows（在用户指南、程序员工具箱、帮助文本和消息中），但还适用于
  IBM i Access Client Solutions - Windows Application Package。


-------------------------------------------------------------------

2.0 信息源的位置

-------------------------------------------------------------------

  - 对 IBM i Access Client Solutions 的更改（包括受支持的操作系统、更新、限制、
    重要的已知问题以及新信息等）将在 IBM i Access 产品 Web 站点上发布：

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - 与此程序包一起安装的用户指南包含有关使用该产品的信息、一些技巧、消息和故障诊断信息。

  - 安装“头、库和文档”功能部件时，会安装针对 OLE DB 提供程序和 .NET 数据提供程序的技术参考。
    可在“程序员工具箱”文件夹中找到这些技术参考。

  - IBM i 信息中心提供了一组针对需要访问技术信息的 IBM i 专家设计的主题：

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - 进行此发布时，IBM i 信息中心未包括关于 IBM i Access Client Solutions 的主题。但是，IBM i Access
    for Windows 下面的大量信息适用于 IBM i Access Client Solutions 的此程序包，其中包括安装主题、
    管理主题和编程主题：

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks 包含为 IBM i 用户提供的文章、教程和技术资源：

    https://www.ibm.com/developerworks/ibmi

  - IBM i Web 站点提供了最新的 IBM i 新闻以及产品信息、参考资料库和教学指南等：

    http://www-03.ibm.com/systems/i/

-------------------------------------------------------------------

3.0 安装信息
-------------------------------------------------------------------



3.1 受支持的 Windows 操作系统
---------------------------------------

  可将此程序包安装在下列 Microsoft Windows 操作系统上：

   

   - Windows Server 2019 Standard 和 Windows Server 2019 Datacenter

   - Windows Server 2016 Standard 和 Windows Server 2016 Datacenter

   - Windows 10 Pro 和 Windows 10 Enterprise

   - Windows 8.1 Pro、Windows 8.1 Enterprise 和 Windows Server 2012 R2

   - Windows Server 2008 和 Windows Server 2008 R2
         Standard Enterprise（32 位和 64 位）
   - Windows 7
         Professional、Enterprise 和 Ultimate（32 位和 64 位）

   存在下列限制：

     a）不支持家庭版。
     b）必须使用 Microsoft 支持的 Windows service pack 级别。
     c）在 Microsoft 停止支持的日期支持将终止。
     d）不支持在 Itanium 硬件上安装。
     e）使用 Microsoft Windows 硬件和内存的建议配置。对于
        IBM i Access Client Solution 函数，请增加 256 MB 内存。
     f）升级至另一 Windows 操作系统时，无法安装该产品。请遵循下列步骤：
          1.  保存配置数据。
2.  卸载该产品。
3.  升级 Windows 操作系统。
4.  安装该产品。
5.  恢复配置数据。


3.2 安装注意事项
--------------------------------------------------

  - 运行安装需要管理权限和特权。

  - 仅支持按机器安装。不支持按用户安装。

  - 需要 Windows Installer 4.5。会在安装期间安装此 Microsoft 软件组件（如果系统上尚未存在该组件）。
    可通过从 Microsoft Web 站点下载此组件来在安装之前安装此组件：

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 从 IBM i Access for Windows 进行升级
----------------------------------------

  -  不支持从 IBM i Access for Windows 进行升级。在安装此程序包之前，
     必须移除 IBM i Access for Windows。

  -  请参阅 1.0 这一节，以获取未包括的功能部件的列表。如果要在
     IBM i Access for Windows 里继续使用本软件包未包括的功能部件，
     请不要安装此软件包，并继续使用 7.1 IBM i Access for Windows
     的最新 Service Pack。

  -  卸载 IBM i Access for Windows 时，将删除现有系统配置。
     要保留现有系统配置，需要在卸载 IBM i Access for Windows
     之前保存配置，并在安装了 IBM i Access Client Solutions Windows
     Application Package 之后，复原该配置。

     以下是用于保存和复原配置的详细步骤：
     1.  使用 CWBBACK 命令来备份 IBM i Access for Windows 配置。
             cwbback <filename.rs> /u
         例如：
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         此示例假定文件夹 C:\Users\IBM_ADMIN\Backup 已存在。

         以上命令将在该文件夹中创建以下两个文件：
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 请确保在转至下一个步骤之前已创建这两个文件。

         注意：
         如果未创建以上两个文件，那么您不具有已保存的配置。尝试以已升级管理员的身份运行
         该命令。执行该操作的一种方式是按如下所示启动命令提示符：
             开始 -> 所有程序 -> 附件 -> 命令提示符
         但是请对“命令提示符”进行右键单击，而不是进行左键单击，然后
         选择“以管理员身份运行”。使用此命令提示符运行以上 cwbback 命令。
         请确保在转至下一个步骤之前已创建以上两个文件。

     2.  卸载 IBM i Access for Windows。
     3.  重新引导。Reboot.
     4.  安装 IBM i Access Client Solutions Windows Application Package。
     5.  重新引导。Reboot.
     6.  使用 CWBREST 命令来复原已使用 CWBBACK 命令保存的配置。
             cwbrest <filename.rs> /c
         例如：
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         如果已要求您遵循步骤 1 的“注意”中的指示信息，那么还需要从已升级管理员
         命令提示符运行 cwbrest 命令。

  -  可以使用两种方式在执行以上步骤之前和之后验证 Windows 配置：
     1. 检查 Windows 注册表。系统配置存储在以下位置：
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	要查看该位置的 Windows 注册表的内容，请输入以下命令：
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"

        如果环境的名称不是缺省的“My Connections”，请在以上路径中进行相应的替换。

     2. 如果您在同一 PC 上具有 IBM i Access Client Solutions 的独立于平台的版本，
        那么可以从主 GUI 面板中进行以下选择：
            文件 -> 复制连接
        右边将显示“IBM i Access (Windows)”。这是同时用于 IBM i Access for Windows 和
        IBM i Access Client Solutions Windows Application Package 的配置。


3.4 运行安装
------------

  - 运行安装映像中的 setup.exe 以启动安装。（此产品未附带交付命令
    cwblaunch.exe。）      注意：建议不要直接调用 Microsoft Installer (MSI) 文件，这是因为
            setup.exe 使用 setup.ini 来获取要使用的命令行选项的列表以及更新
            Windows Installer 版本（需要时）。

  - 建议使用缺省目标文件夹。但是，如果更改该文件夹，那么：

     a）请不要选择驱动器的根目录。
     b）请不要选择已包含此产品的不相关文件的目录。
     c）请不要选择网络驱动器。不支持安装到网络驱动器上。



3.5 安装打印机驱动程序之后需要执行的操作
---------------------------------------------------

  如果安装 APF 打印机驱动程序，那么在使用该打印机驱动程序之前，必须执行操作。
  由于 Microsoft 不会对该打印机驱动程序进行数字签名，所以在安装期间，该打印机驱动程序
  无法自动添加或更新，因此需要执行操作。

  在安装期间，会将打印机驱动程序文件复制到已选择的目标路径下面名为
  CWBAFP 的子目录中。假定您已安装到缺省目标路径中，那么该路径将如下：

  c:\Program Files\IBM\Client Access\CWBAFP directory 

  请使用 Microsoft 在其帮助文本中提供的指示信息，以添加或更新该打印机驱动程序。
  当系统出现提示时，请指定 CWBAFP 的路径。

  如果在已升级基于多个发行版的 IBM i Access for Windows 产品的 PC 上进行安装，
  那么在配置该打印机驱动程序时可能显示一些旧信息。要从 .inf 文件中除去过时信息，
  请在完成安装之后执行下列步骤：  

    a）打开命令提示符窗口。
    b）将目录切换至安装目录。缺省安装目录是
    c:\Program Files\IBM\Client Access。
    c）输入“cwbrminf”并按 Enter 键。


3.6 64 位硬件安装注意事项
-----------------------------------------------

  在受支持的 64 位 Windows 操作系统上安装时：

  - 会同时安装 32 位版本和 64 位版本的 ODBC、OLE DB、ActiveX 和安全套接字层 (SSL)。

  - IBM i Access for Windows .NET 提供程序会从 32 位和 64 位应用程序运行，这取决于调用
    该提供程序的应用程序。

  - 仅会安装 AFP 打印机驱动程序的一个版本。64 位版本安装在
    64 位系统上，32 位版本安装在 32 位系统上。


3.7 安装日志
---------------------

  在安装期间，会创建两个日志。其中一个日志特定于 XJ1 并且包含该产品的定制操作信息。
  此日志名为“xe1instlog.txt”，
  并且始终在用户临时目录中创建。

  另一个日志是 Microsoft MSI 日志，它包含有关 MSI 事件、序列和属性的信息。
  缺省情况下，此日志名为“xe1instlogmsi.txt”，
  并且在用户临时目录中创建。可以通过编辑安装映像中的 setup.ini
  来更改此日志。请转至 [Startup] 关键字，找到并编辑以下项：

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - 要防止创建该日志，请除去该项
    - 要更改该日志的位置和名称，请更改路径和文件名
    - 要更改该日志的内容，请按 Microsoft 位于以下位置的
      MSDN Windows Installer Command Line Options 中的描述来将
      /l* 更改为另外的选项

      http://msdn.microsoft.com/default.aspx   

  可通过在命令提示符处带命令行选项启动 setup.exe 来覆盖 setup.ini
  中的缺省命令行信息。



-------------------------------------------------------------------

4.0 IBM.Data.DB2.iSeries .NET 提供程序要求

-------------------------------------------------------------------

  - IBM i Access for Windows .NET 提供程序 (IBM.Data.DB2.iSeries)
    要求在系统上安装 Microsoft .NET Framework V2.0 或更高版本。
    运行受支持 Microsoft 操作系统的大多数 PC 已安装必需的
    .NET Framework。可从 Microsoft Web 站点上的以下位置
     下载 .NET Framework：

    http://www.microsoft.com/net 

  - 要避免中断已对 Access for Windows 5.3 或 5.4 .NET 提供程序接口编写的 .NET 应用程序，
    必须将运行时对 .NET 提供程序 10.0.0.0 版本的请求重定向至 12.0.0.0 版本。请参阅
    《IBM DB2 for i.NET 提供程序技术参考》中的“5.3 和 5.4 中的不兼容更改”主题，
    以获取有关使用 app.config 文件、web.config 文件或 machine.config 文件的指示信息
    以及有关为重定向现有应用程序选择相应编译器的信息。

    或者，可以 IBM i Access for Windows 7.1 发行版中包括的 12.0.0.0 版本的 .NET
    提供程序为目标，使用较新版本的编译器重新编译该应用程序。

  - 要获取完整信息以及不兼容更改的列表，请安装“头、库和
    文档”功能部件，然后显示《.NET 提供程序技术参考》。

-------------------------------------------------------------------

5.0 Microsoft XML Parser 或 Microsoft XML Core Services

-------------------------------------------------------------------

  当使用 IBM i Access for Windows 数据传输 ActiveX 自动化对象来将文件传输至
  Microsoft Excel XML 格式（受 Excel 2003 和 Excel XP 支持）以及从该格式传输
  文件时，必须在 PC 上安装额外的软件。此功能要求在个人计算机上安装
  Microsoft XML Parser（也称为 Microsoft XML Core Services）3.0 或更高版本。
  XML Parser 包括在许多 Microsoft 产品中。要确定 PC 上是否安装了 XML Parser 支持，
  请参阅 Microsoft KB 文章 278674。可以在 Microsoft Web 站点上的以下位置找到该文章：


  http://support.microsoft.com/kb/278674

  如果找不到 Microsoft XML Parser 3.0 或更高版本，那么需要访问 Microsoft Web 站点以获取有关
  下载和安装 XML Parser 的指示信息，才能使用数据传输 XML 支持。
  请参阅 Microsoft KB 文章 324460 以获取有关安装 XML Parser 的信息。可在以下位置找到该文章：


  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 高级安装信息

-------------------------------------------------------------------

  可使用 IBM i Access for Windows 的 IBM i 信息中心内“设置 PC”主题中大多数有关修改用户接口级别、
  使用命令行参数以及控制其他安装行为和部署方法的信息。在本节中对差别进行了描述。


6.1 许可产品信息
----------------------------------

  5733XJ1 未打包为要在 IBM i 操作系统上安装的许可产品。
  它仅以 PC 介质的形式提供。可将它复制到 IBM i 上用户可访问的位置（如果愿意）。
  

6.2 安装映像中的语言文件
--------------------------------------------

  在安装映像中，语言安装文件不再分成不同的 MRI29xx 目录。
  而是对于每种语言，都存在不同的 cab 文件。不能从映像中
  除去这些 cab 文件。


6.3 安装功能部件
--------------------

  IBM i Access for Windows 中的一些安装功能部件依赖于要安装的其他安装功能部件。
  此限制不适用于此程序包。

  需要安装下列安装功能部件：
    req（必需的程序）
    langacs 和 amri2924（英语）

  在缺省情况下，会安装所有其他安装功能部件，但是可更改该设置。

  语言现在是安装功能部件，正如必需的程序和 ODBC 等。由于语言是安装功能部件，因此可控制安装
  哪些语言，使用的方法与用于控制任何安装功能部件的方法相同。这些语言的安装功能部件名称是
  amri29xx。


6.4 命令行选项
------------------------

  缺省命令行选项是在安装映像中包括的 setup.ini 文件中指定的。
  如果从命令行带任何指定选项调用 setup.exe，那么将忽略缺省命令行选项。

  如果正在命令行上使用变换，那么由于该变换是选项，将忽略 setup.ini 中的命令行值。
  将需要在命令行上包括其他选项，例如日志记录信息。

  请参阅“3.7 安装日志”这一节，以获取更多信息。


6.5 公共属性
---------------------

  IBM i Access for Windows 的某些公共属性适用于此程序包。该用法相对于
  IBM i Access for Windows 中的用法有一些变化，如下所述：

  CWBINSTALLTYPE   此属性仅在第一次安装时使用。仅有的值是 Typical 和 Custom。
                   缺省值是 Typical。
                   示例：setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   缺省主语言是 PC 的语言环境。此属性允许您指定另一主语言。
                   要使用的值是 MRI29xx。
                   示例：setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   此属性的用法与它在 IBM i Access for Windows 中的用法相同。它允许您在升级期间升级
                   SSL 文件。如果在目标 PC 上找到 SSL 的配置文件，那么将使用最新的证书来更新这些文件。
                   值为 Yes 和 No。缺省值是 Yes。
                   示例：setup /vCWBUPGSSLFILES=NO

  “IBM i Access for Windows 信息中心”主题中列示的常用 Windows Installer 属性仍然适用：
  ADDLOCAL、REMOVE、INSTALLDIR 和 TARGETDIR。

  存在一个关于将 REBOOT Windows Installer 属性与 IBM i Access for Windows 配合使用的限制。
  此限制不适用于此程序包。
  

6.6 将管理映像刻录至 CD 或 DVD
----------------------------------------------

  由于有关某些 CD 和 DVD 刻录软件处理长文件名方式的问题，
  建议不要将管理映像刻录至 CD 或 DVD。如果从包含 IBM i Access for
     Windows 的管理映像的 CD 或 DVD 安装时遇到问题，请将该映像复制到本地硬盘上的目录，
     然后从本地副本运行 setup.exe。

-------------------------------------------------------------------
7.0 策略信息
-------------------------------------------------------------------

  同一策略文件用于此程序包和 IBM i Access for Windows。这意味着当用于此程序包时其中一些
  策略不适用（因为 IBM i Access for Windows 中的某些功能在此程序包中不存在）。

-------------------------------------------------------------------

8.0 命令
-------------------------------------------------------------------

  IBM i Access for Windows 内未包括在此程序包中的命令：
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe

[文档结束]
