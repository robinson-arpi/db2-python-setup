==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0

    (c) Copyright IBM Corporation 1996, 2019.  Alle Rechte vorbehalten.

==============================================================================
  IBM übernimmt keine Haftung für das vorliegende Dokument. Mit der
  Auslieferung dieses Dokuments ist keine Lizenzierung von Patenten
  oder Urheberrechten verbunden.

===============================================================================

Letzte Aktualisierung dieses Dokuments am:  04. November 2019

------------------------------------------------------------------- 

INHALTSVERZEICHNIS

-------------------------------------------------------------------  

1.0 Einführung
2.0 Position von Informationsquellen
3.0 Installation
  3.1 Unterstützte Windows-Betriebssysteme
  3.2 Installationsvoraussetzungen
  3.3 Upgrade von IBM i Access für Windows
  3.4 Ausführung der Installation
  3.5 Nach Installation von Druckertreibern erforderliche Aktion
  3.6 Installationshinweise für 64-Bit-Hardware
  3.7 Installationsprotokolle
4.0 Voraussetzungen des .NET-Providers für IBM.Data.DB2.iSeries
5.0 Microsoft XML Parser oder Microsoft XML Core Services
6.0 Weitere Installationsinformationen
  6.1 Informationen zum Lizenzprogramm
  6.2 Dateien mit sprachabhängigen Anweisungen im Installationsimage
  6.3 Installationsfeatures
  6.4 Befehlszeilenoptionen
  6.5 Allgemeine Eigenschaften
  6.6 Verwaltungsimages auf CD oder DVD brennen
7.0 Richtlinieninformationen
8.0 Befehle
  


-------------------------------------------------------------------

1.0 Einführung
-------------------------------------------------------------------
  Dieses Paket ist Teil des Produkts IBM i Access Client Solutions (5733XJ1). 

  Sie können mit IBM i Access Client Solutions eine Verbindung zu allen
  unterstützten IBM i-Releases herstellen.

  Dieses Paket enthält Funktionen, die nur unter Windows-Betriebssystemen
  verfügbar sind. Das Produkt basiert auf IBM i Access für Windows 7.1,
  enthält jedoch nicht alle Features. 

  Dieses Paket enthält die folgenden Features von IBM i Access für Windows:
    .NET Data Provider
    ODBC
    OLE DB
    Secure Sockets Layer und Zertifikatsverwaltung
    Programmierer-Toolkit für Header, Bibliotheken und Dokumentation
    AFP-Druckertreiber
    Erforderliche Programme, einschließlich:
      APIs
      Active X
      Sicherheit
      Serviceoptionen
      Verbindungen
      Unterstützung in der Landessprache
      Umsetzungstabellen
      Eigenschaften
      Richtlinien
      Netzwerkdruck
      Teilmenge an Befehlen (eine Liste der nicht enthaltenen Befehle
         finden Sie in Abschnitt 8.0)
      Benutzerhandbuch
      Verwenden der Anwendungsverwaltung, um den Zugriff auf Funktionen im
      Paket zu steuern

  Folgende Features von IBM i Access für Windows sind in diesem Paket nicht enthalten. 
  Das plattformunabhängige Paket IBM i Access Client Solutions enthält
  Ersatzfunktionen für die folgenden Features:
    PC5250-Anzeige- und Druckeremulation
    Datenübertragung
    Excel-Add-in für Datenübertragung
    Operations Console

  Folgende Features von IBM i Access für Windows sind in diesem Paket nicht enthalten. 
  IBM Navigator for i enthält Ersatzfunktionen für die folgenden Features:
    System i Navigator
    AFP Workbench Viewer

  Das Feature "Eingehender ferner Befehl" ist nicht enthalten. Verwenden Sie
  stattdessen die Remotedesktopdienste von Microsoft. 

  Die Toolbox für Java ist ebenfalls nicht enthalten. Downloadinformationen finden Sie
  auf der folgenden Website:

  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Folgende weitere Features von IBM i Access für Windows sind in diesem Paket
  nicht enthalten:
    SCS-Druckertreiber
    Java-Programmierertools für System i Navigator-Plug-ins
    Verzeichnisaktualisierung
    Unterstützung für Lotus 123-Dateiformat
    Service-Level überprüfen

  Da der Inhalt dieses Pakets auch mit IBM i Access für Windows 7.1
  ausgeliefert wird, beziehen sich Dokumentation und Versionierung
  in Benutzerhandbuch, Programmierer-Toolkit, Hilfetext und
  Nachrichten oftmals auf IBM i Access für Windows 7.1. Die
  Informationen gelten jedoch auch für das IBM i Access Client
  Solutions - Windows Application Package.



-------------------------------------------------------------------

2.0 Position von Informationsquellen

-------------------------------------------------------------------

  - Änderungen an IBM i Access Client Solutions, einschließlich unterstützte
    Betriebssysteme, Updates, Einschränkungen, wichtige bekannte Probleme, neue
    Informationen und anderes werden auf der Produktwebsite für IBM i Access
    veröffentlicht:  

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Das mit diesem Paket installierte Benutzerhandbuch enthält Informationen zur
    Verwendung des Produkts, Tipps und Verfahrensweisen, Nachrichten sowie
    Fehlerbehebungsinformationen.

  - Technische Referenzen zum OLE DB-Provider und zum .NET Data Provider werden
    bei der Installation des Features "Header, Bibliotheken und Dokumentation"
    installiert. Sie finden die technischen Referenzen im Ordner für das
    Programmierer-Toolkit. 

  - Das IBM i Information Center stellt eine Datensammlung aus Themen bereit, die für
    professionelle IBM i-Anwender entwickelt wurde, um ihnen Zugriff auf technische
    Informationen zu bieten: 

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - Zum Zeitpunkt der Veröffentlichung enthielt das IBM i Information Center
    keine Themen zu IBM i Access Client Solutions. Allerdings treffen viele
    der Informationen zu IBM i Access für Windows auch auf dieses Paket von
    IBM i Access Client Solutions zu, darunter die Themen zu Installation,
    Verwaltung und Programmierung: 

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks enthält Artikel, Lernprogramme und technische Ressourcen
    für Benutzer von IBM i: 

    https://www.ibm.com/developerworks/ibmi

  - Die IBM i-Website stellt die aktuellsten Neuigkeiten über IBM i sowie
    Produktinformationen, eine Bibliothek mit Referenzinformationen,
    Schulungsübersichten und anderes bereit: 

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Installationsinformationen
-------------------------------------------------------------------



3.1 Unterstützte Windows-Betriebssysteme
----------------------------------------

  Dieses Paket kann unter den folgenden Microsoft Windows-Betriebssystemen
  installiert werden:

   

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2

   - Windows Server 2008 und Windows Server 2008 R2
         Standard Enterprise (32-Bit- und 64-Bit-Version)
   - Windows 7
         Professional, Enterprise und Ultimate (32-Bit- und 64-Bit-Version)

   Es gelten folgende Einschränkungen:

     a) Home-Editionen werden nicht unterstützt.
     b) Sie müssen Service-Pack-Levels für Windows verwenden, die von
        Microsoft unterstützt werden.
     c) Der Support wird an dem Datum eingestellt, an dem Microsoft den
        Support beendet.
     d) Eine Installation auf Itanium-Hardware wird nicht unterstützt.
     e) Verwenden Sie die Hardware- und Speicherempfehlungen für Microsoft
        Windows. Kalkulieren Sie zusätzlich 256 MB an Speicher für die
        Funktionen von IBM i Access Client Solutions ein.
     f) Das Produkt kann nicht installiert werden, wenn Sie ein Upgrade auf ein anderes
        Windows-Betriebssystem durchführen. Führen Sie die folgenden Schritte aus:
          1.  Speichern Sie die Konfigurationsdaten.
          2.  Deinstallieren Sie das Produkt.
          3.  Führen Sie ein Upgrade des Windows-Betriebssystems durch.
          4.  Installieren Sie das Produkt.
          5.  Stellen Sie die Konfigurationsdaten wieder her. 


3.2 Installationsvoraussetzungen
--------------------------------

  - Zur Ausführung der Installation ist die Administratorberechtigung
    erforderlich.

  - Es werden nur Installationen für Systeme unterstützt. Installationen
    für Benutzer werden nicht unterstützt. 

  - Windows Installer 4.5 ist erforderlich. Diese Softwarekomponente von
    Microsoft wird bei der Installation installiert, sofern sie noch nicht
    auf dem System vorhanden ist. Sie können die Komponente vor der
    Installation installieren, indem Sie sie von der Microsoft-Website
    herunterladen: 

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Upgrade von IBM i Access für Windows
----------------------------------------

  -  Keine Unterstützung für ein Upgrade von IBM i Access für Windows. Vor der Installation
     dieses Pakets müssen Sie zunächst IBM i Access für Windows entfernen. 

  -  Eine Liste der nicht enthaltenen Features finden Sie in Abschnitt 1.0. Wenn Sie weiterhin Features
     von IBM i Access für Windows, die nicht Teil dieses Pakets sind, nutzen möchten,
     müssen Sie die Installation des Pakets unterlassen und mit dem neuesten Service-Pack
     von IBM i Access für Windows 7.1 weiterarbeiten. 

  -  Bei der Deinstallation von IBM i Access für Windows wird die vorhandene System-
     konfiguration gelöscht. Um diese zu erhalten, müssen Sie die Konfiguration
     vor der Deinstallation von IBM i Access für Windows sichern und sie dann
     wiederherstellen, nachdem das IBM i Access Client Solutions Windows Application
     Package installiert wurde.

     Im Folgenden sind die ausführlichen Schritte zum Sichern und Wiederherstellen Ihrer Konfiguration aufgeführt:
     1.  Verwenden Sie den Befehl CWBBACK, um die Konfigurationsdaten von
         IBM i Access für Windows zu sichern.
         cwbback <dateiname.rs> /u
         Zum Beispiel:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Bei diesem Beispiel wird davon ausgegangen, dass der Ordner
         C:\Users\IBM_ADMIN\Backup bereits vorhanden ist. 

         Mit dem obigen Befehl werden zwei Dateien in diesem Ordner erstellt:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
       	 Stellen Sie sicher, dass diese zwei Dateien erstellt wurden, bevor Sie mit dem nächsten Schritt fortfahren. 

         HINWEIS:
         Wenn die beiden oben genannten Dateien nicht erstellt wurden, liegt keine gesicherte Konfiguration vor.
         Versuchen Sie den Befehl als Administrator mit erweiterter Berechtigung auszuführen.
         Eine mögliche Vorgehensweise dafür ist, eine Eingabeaufforderung wie folgt zu starten:
             Start->Alle Programme->Zubehör->Eingabeaufforderung
         Aber anstatt mit der linken Maustaste auf Eingabeaufforderung zu klicken,
         klicken Sie mit der rechten Maustaste und wählen Sie die Option für die
         Ausführung als Administrator aus.
         Rufen Sie den obigen Befehl cwbback unter Verwendung dieser Eingabeaufforderung auf.
         Stellen Sie sicher, dass die oben genannten zwei Dateien erstellt wurden, bevor Sie
         mit dem nächsten Schritt fortfahren. 

               2.  Deinstallieren Sie IBM i Access für Windows.
          3.  Führen Sie einen Warmstart durch.
          4.  Installieren Sie das IBM i Access Client Solutions Windows Application Package.
               5.  Führen Sie einen Warmstart durch.
     6.  Verwenden Sie den Befehl CWBREST, um die mit dem Befehl CWBBACK gesicherten Konfigurationsdaten
              wiederherzustellen.
              cwbrest <dateiname.rs> /c
              Zum Beispiel:
              cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Wenn Sie den Anweisungen in dem Hinweis von Schritt 1 folgen mussten, müssen Sie den
         Befehl cwbrest auch von einer Eingabeaufforderung für einen Administrator mit erweiterter
         Berechtigung ausführen.


  -  Sie haben mehrere Möglichkeiten, Ihre Windows-Konfiguration vor und nach den
     oben aufgeführten Schritten zu prüfen:
     1. Prüfen Sie die Windows-Registrierungsdatenbank. Die Systemkonfigurationen sind im folgenden Verzeichnis gespeichert:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	       Um den Inhalt der Windows-Registrierungsdatenbank an dieser Position anzuzeigen, geben Sie den folgenden Befehl ein:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"

        Bei einer Umgebung, die anders als standardmäßig "My Connections" benannt ist,
        geben Sie den entsprechenden Namen im obigen Pfad an. 

     2. Wenn Sie die plattformunabhängige Version von IBM i Access Client Solutions auf demselben
        PC haben, können Sie in der GUI-Hauptanzeige Folgendes auswählen:
            Datei->Verbindungen kopieren
        Auf der rechten Seite wird "IBM i Access (Windows)" angezeigt. Dies ist die Konfiguration, die sowohl für
        IBM i Access für Windows als auch für IBM i Access Client Solutions Windows Application Package verwendet wird.


3.4 Ausführung der Installation
-------------------------------

  - Führen Sie die setup.exe im Installationsimage aus, um die Installation zu starten.
   (Der Befehl "cwblaunch.exe" ist in diesem Produkt nicht verfügbar.) 
   ANMERKUNG: Der direkte Aufruf von Microsoft Installer-Dateien wird
              nicht empfohlen, weil die setup.exe eine Datei "setup.ini"
              wegen einer Liste mit zu verwendenden Befehlszeilenoptionen
              nutzt und die Windows Installer-Version bei Bedarf aktualisiert.

  - Es wird empfohlen, den Standardzielordner zu verwenden. Bei einer
     Änderung des Ordners ist jedoch Folgendes zu berücksichtigen: 
     a) Wählen Sie nicht das Stammverzeichnis eines Laufwerks aus.
     b) Wählen Sie kein Verzeichnis aus, das bereits Dateien enthält, die
        nicht zu diesem Produkt gehören.
     c) Wählen Sie kein Netzlaufwerk aus. Die Installation auf einem
        Netzlaufwerk wird nicht unterstützt.



3.5 Nach Installation von Druckertreibern erforderliche Aktion
---------------------------------------------------------------

  Wenn Sie den AFP-Druckertreiber installieren, müssen Sie vor seiner Verwendung
  bestimmte Maßnahmen durchführen. Dies ist erforderlich, weil der Druckertreiber
  von Microsoft nicht digital signiert wurde und bei der Installation nicht
  automatisch hinzugefügt oder aktualisiert werden kann.


  Während der Installation werden die Druckertreiberdateien in ein
  Unterverzeichnis mit dem Namen CWBAFP des gewählten Zielpfads kopiert.
  Der Pfad würde wie folgt lauten, wenn Sie das Produkt unter dem
  Standardzielpfad installieren würden: 

  c:\Program Files\IBM\Client Access\CWBAFP-Verzeichnis 

  Verwenden Sie die Anweisungen im Hilfetext von Microsoft, um den Druckertreiber
  hinzuzufügen oder zu aktualisieren. Geben Sie den Pfad zum Verzeichnis CWBAFP an,
  wenn Sie dazu aufgefordert werden. 

  Wenn Sie die Installation auf einem PC vornehmen, auf dem Upgrades für
  IBM i Access für Windows über mehrere Releases erfolgt sind, werden bei
  der Konfiguration eines Druckertreibers möglicherweise einige ältere
  Informationen angezeigt. Um die veralteten Informationen aus den
  INF-Dateien zu entfernen, führen Sie nach Abschluss der Installation
  folgende Schritte aus aus:


    a) Öffnen Sie ein Fenster mit Eingabeaufforderung.
    b) Wechseln Sie in Ihr Installationsverzeichnis. Das
       Standardinstallationsverzeichnis ist
       "c:\Program Files\IBM\Client Access".
    c) Geben Sie "cwbrminf" ein, und drücken Sie die Eingabetaste. 


3.6 Installationshinweise für 64-Bit-Hardware
--------------------------------------------- 

  Installation unter einer unterstützten 64-Bit-Version des Windows-Betriebssystems:

  -  Für ODBC, OLE DB, ActiveX und Secure Sockets Layer (SSL) wird sowohl die
     32-Bit-Version als auch die 64-Bit-Version installiert. 

  -  Der .NET-Provider von IBM i Access für Windows kann sowohl über 32-Bit-
     als auch über 64-Bit-Anwendungen ausgeführt werden. Die Art der Ausführung
     ist von der Anwendung abhängig, die den Provider aufruft.


  -  Es wird nur eine Version des AFP-Druckertreibers installiert. Die
     64-Bit-Version wird auf 64-Bit-Systemen und die 32-Bit-Version auf
     32-Bit-Systemen installiert. 


3.7 Installationsprotokolle
---------------------------

  Bei der Installation werden zwei Protokolle erstellt. Eines der Protokolle ist
  spezifisch für XJ1 und enthält die Informationen über angepasste Aktionen des
  Produkts. Dieses Protokoll heißt "xe1instlog.txt" und wird immer im Verzeichnis
  "temp" des Benutzers erstellt. 

  Bei dem anderen Protokoll handelt es sich um das MSI-Protokoll von Microsoft,
  das Informationen über MSI-Ereignisse, -Sequenzen und Eigenschaften enthält.
  Dieses Protokoll heißt standardmäßig "xe1instlogmsi.txt" und wird im
  Verzeichnis "temp" des Benutzers erstellt. Zur Änderung dieses Protokolls
  können Sie die Datei "setup.ini" im Installationsimage bearbeiten.
  Gehen Sie zum Schlüsselwort [Startup], suchen Sie nach dem folgenden Eintrag
  und bearbeiten Sie ihn: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Entfernen Sie den Eintrag, um die Erstellung des Protokolls zu verhindern.
    - Ändern Sie den Pfad und Dateinamen, um die Position und den Namen des
      Protokolls zu ändern.
    - Ändern Sie die Angabe "/l*" in eine oder mehrere andere Optionen, um den
      Inhalt des Protokolls zu ändern. Entsprechende Informationen finden Sie in
      den Angaben zu den Befehlszeilenoptionen für den MSDN Windows Installer
      von Microsoft, die Sie unter der folgenden Adresse aufrufen können: 

      http://msdn.microsoft.com/default.aspx   

  Die Standardbefehlszeileninformationen in der Datei "setup.ini" können
  überschrieben werden, indem Sie die Datei "setup.exe" unter Angabe von
  Befehlszeilenoptionen an der Eingabeaufforderung starten. 



-------------------------------------------------------------------

4.0 Voraussetzungen des .NET-Providers für IBM.Data.DB2.iSeries

-------------------------------------------------------------------

  - Der .NET-Provider für IBM i Access für Windows (IBM.Data.DB2.iSeries)
    erfordert die Installation des .NET Framework von Microsoft (Version 2.0
    oder eine spätere Version) auf dem System.
    Auf den meisten PCs, auf denen unterstützte Microsoft-Betriebssysteme
    ausgeführt werden, ist das erforderliche .NET Framework bereits installiert.
    Das .NET Framework kann von der Microsoft-Website unter der folgenden
    Adresse heruntergeladen werden:


    http://www.microsoft.com/net     

  - Um Störungen bei vorhandenen .NET-Anwendungen, die für die
    .NET-Provider-Schnittstelle von Access für Windows 5.3 oder 5.4
    geschrieben wurden, zu verhindern, müssen Laufzeitanforderungen
    für die Version 10.0.0.0 des .NET-Providers zur neuen Version 12.0.0.0
    umgeleitet werden. Anweisungen für die Verwendung einer Datei
    "app.config", "web.config" oder "machine.config" sowie Informationen zur
    Auswahl eines geeigneten Compilers für die Umleitung vorhandener Anwendungen
    enthält der Abschnitt "Inkompatible Änderungen gegenüber 5.3 und 5.4"
    in der technischen Referenz zum .NET-Provider für IBM DB2 für i. 

    Alternativ kann die Anwendung mit einem neueren Compiler erneut
    kompiliert werden, um auf Version 12.0.0.0 des .NET-Providers
    abzuzielen, die in Release 7.1 von IBM i Access für Windows
    enthalten ist. 

  - Umfassende Informationen und eine Liste der inkompatiblen Änderungen
    erhalten Sie, wenn Sie das Feature "Header, Bibliotheken und
    Dokumentation" installieren und dann das Dokument "Technische Referenz"
    zum .NET Provider anzeigen. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser oder Microsoft XML Core Services 

-------------------------------------------------------------------

  Wenn Sie die ActiveX-Automatisierungsobjekte der Datenübertragung von
  IBM i Access für Windows verwenden, um Dateien in und aus dem XML-Format
  von Microsoft Excel zu übertragen (von Excel 2003 und Excel XP unterstützt),
  muss zusätzliche Software auf dem PC installiert werden. Für dieses
  Feature muss Microsoft XML Parser 3.0 oder höher (wird auch Microsoft XML
  Core Services genannt) auf dem Personal Computer installiert sein. Der
  XML-Parser ist in vielen Microsoft-Produkten enthalten. Um festzustellen,
  ob die Unterstützung für den XML-Parser installiert ist, lesen Sie den
  Microsoft-KB-Artikel 278674. Diesen Artikel finden Sie auf der
  Microsoft-Website unter folgender Adresse:

  http://support.microsoft.com/kb/278674

  Wenn der Microsoft-XML-Parser 3.0 oder höher nicht vorhanden ist, müssen
  Sie über die Microsoft-Website auf die Anweisungen zum Download und zur
  Installation des XML-Parsers zugreifen, bevor Sie die XML-Unterstützung
  der Datenübertragung verwenden können. Der Microsoft-KB-Artikel 324460
  enthält Informationen zur Installation des XML-Parsers.
  Diesen Artikel finden Sie unter folgender Adresse:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Weitere Installationsinformationen

-------------------------------------------------------------------

  Sie können den Großteil der Informationen zum Ändern der
  Benutzerschnittstellenebene, zum Verwenden von
  Befehlszeilenparametern, zum Steuern des sonstigen
  Installationsverhaltens und der Implementierungsmethoden im
  Thema zur PC-Einrichtung im IBM i Information Center für
  IBM i Access für Windows verwenden. Die Unterschiede werden
  in diesem Abschnitt beschrieben. 


6.1 Informationen zum Lizenzprogramm
------------------------------------

  5733XJ1 ist nicht als Lizenzprogramm gepackt, um es unter dem Betriebssystem
  IBM i zu installieren. Es ist nur als PC-Medium verfügbar. Falls gewünscht,
  können Sie das Programm auf der IBM i an eine Position kopieren, die für
  Ihre Benutzer verfügbar ist.
  

6.2 Dateien mit sprachabhängigen Anweisungen im Installationsimage
------------------------------------------------------------------

  Die Installationsdateien mit sprachabhängigen Anweisungen sind im
  Installationsimage nicht mehr in verschiedene MRI29xx-Verzeichnisse
  aufgeteilt. Für jede Sprache gibt es stattdessen separate CAB-Dateien.
  Sie können diese CAB-Dateien nicht aus dem Image entfernen. 


6.3 Installationsfeatures
-------------------------

  Manche Installationsfeatures in IBM i Access für Windows waren von
  anderen zu installierenden Installationsfeatures abhängig. Diese
  Einschränkung gilt nicht für dieses Paket. 

  Folgende Installationsfeatures müssen installiert werden:
    req (erforderliche Programme)
    langacs, amri2924 (Englisch)

  Alle anderen Installationsfeatures werden standardmäßig installiert,
  Sie können die Einstellung jedoch ändern.

  Sprachen sind jetzt Installationsfeatures, genauso wie erforderliche
  Programme, ODBC etc. Da Sprachen Installationsfeatures sind, können
  Sie mit den Methoden zur Steuerung von Installationsfeatures steuern,
  welche Sprachen installiert werden. Die Installationsfeatures für
  Sprachen heißen amri29xx. 


6.4 Befehlszeilenoptionen
-------------------------

  Die Standardbefehlszeilenoptionen sind in der Datei "setup.ini" angegeben,
  die im Installationsimage enthalten ist. Diese Optionen werden ignoriert,
  wenn Sie die Datei "setup.exe" von der Befehlszeile aus aufrufen und dabei
  Optionen angeben. 

  Wenn Sie in der Befehlszeile eine Umsetzung verwenden, werden die
  Befehlszeilenwerte in der Datei "setup.ini" ignoriert, weil die
  Umsetzung eine Option ist. Sie müssen weitere Optionen in der
  Befehlszeile angeben, z. B. Protokolldaten. 

  Weitere Informationen finden Sie im Abschnitt "3.7 Installationsprotokolle". 


6.5 Allgemeine Eigenschaften
----------------------------

  Einige der allgemeinen Eigenschaften von IBM i Access für Windows gelten
  für dieses Paket. Die Verwendung unterscheidet sich wie hier beschrieben
  gelegentlich von der Verwendung in IBM i Access für Windows: 

  CWBINSTALLTYPE   Diese Eigenschaft wird nur bei einer Erstinstallation
                   verwendet. Die einzigen Werte sind "Typical" und "Custom".
                   Der Standardwert ist "Typical".
                   Beispiel: setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   Die Standardprimärsprache ist die länderspezifische Angabe
                   des PC. Mit dieser Eigenschaft können Sie eine andere
                   Primärsprache angeben. Der zu verwendende Wert ist MRI29xx. 
                   Beispiel: setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   Die Verwendung dieser Eigenschaft entspricht der bei IBM i
                   Access für Windows. Damit können Sie die SSL-Dateien bei
                   einem Upgrade aktualisieren. Wenn die Konfigurationsdateien
                   für SSL auf dem Ziel-PC gefunden werden, werden die Dateien
                   mit den neuesten Zertifikaten aktualisiert. Die Werte sind
                   "Yes" und "No". Der Standardwert ist "Yes".
                   Beispiel: setup /vCWBUPGSSLFILES=NO

  Die allgemeinen Windows Installer-Eigenschaften, die im Thema des Information
  Centers für IBM i Access für Windows aufgelistet sind, sind weiterhin gültig:
  ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.


  Bei der Verwendung der Windows Installer-Eigenschaft REBOOT mit IBM i Access
  für Windows gibt es eine Einschränkung. Diese Einschränkung gilt nicht für
  dieses Paket.


6.6 Verwaltungsimages auf CD oder DVD brennen
---------------------------------------------

  Da einige zum Brennen von CDs und DVDs verwendete Softwareprodukte bei langen
  Dateinamen Probleme haben, ist es nicht empfehlenswert, ein Verwaltungsimage
  auf eine CD oder DVD zu brennen. Wenn bei der Installation von einer CD oder
  DVD, die ein Verwaltungsimage von IBM i Access für Windows enthält, Probleme
  auftreten, kopieren Sie das Image in ein Verzeichnis auf der lokalen Festplatte
  und führen Sie die setup.exe von dieser lokalen Kopie aus.


-------------------------------------------------------------------
7.0 Richtlinieninformationen
-------------------------------------------------------------------

  Für dieses Paket und IBM i Access für Windows wird die gleiche
  Richtliniendatei verwendet. Das bedeutet, dass manche dieser
  Richtlinien nicht gelten, wenn sie für dieses Paket verwendet
  werden, weil einige der Funktionen von IBM i Access für Windows
  in diesem Paket nicht vorhanden sind. 

-------------------------------------------------------------------

8.0 Befehle
-------------------------------------------------------------------

  Folgende Befehle von IBM i Access für Windows sind in diesem Paket nicht enthalten:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe


   [ENDE DES DOKUMENTS]
