==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2022.  All rights reserved. 

==============================================================================
  This document is provided "as is" without warranty of any kind.  IBM disclaims 
  all warranties, whether expressed or implied, including without limitation, the
  implied warranties of fitness for a particular purpose and merchantability
  with respect to the information in this document. By furnishing this document,
  IBM grants no licenses to any patents or copyrights. 

===============================================================================

This document was last updated on:  May 09, 2023

------------------------------------------------------------------- 

TABLE OF CONTENTS 

-------------------------------------------------------------------  

1.0 Introduction
2.0 Location of Information Sources
3.0 Installation
  3.1 Supported Windows Operating Systems
  3.2 Installation Considerations
  3.3 Upgrading from IBM i Access for Windows
  3.4 Running the Install
  3.5 Action Required After Installing Printer Driver
  3.6 64-bit hardware installation considerations
  3.7 Installation logs 
4.0 IBM.Data.DB2.iSeries .NET Provider Requirements
5.0 Microsoft XML Parser or Microsoft XML Core Services
6.0 Advanced Installation Information
  6.1 Licensed Product Information
  6.2 Language Files in the Installation Image
  6.3 Install Features
  6.4 Command line options
  6.5 Public Properties
  6.6 Burning Administrative Images to CD or DVD 
7.0 Policy Information
8.0 Commands Not Included
  


-------------------------------------------------------------------

1.0 Introduction
-------------------------------------------------------------------
  This package is part of the 5733XJ1 IBM i Access Client Solutions product.

  You can use IBM i Access Client Solutions to connect to any supported IBM i
  release.

  This package contains functions that are only available on Windows operating 
  systems.  It is based on 7.1 IBM i Access for Windows product but does not 
  contain all of the features.

  The features included in this package from IBM i Access for Windows are:
    .NET Data Provider
    ODBC
    OLE DB
    Secure Socket Layer and Certificate Management
    Programmer's Toolkit for Headers, Libraries and Documentation
    AFP Printer Driver
    Required Programs including:
      APIs
      Active X
      Security
      Serviceability
      Connections
      NLS enablement
      Conversion tables
      Properties
      Policies
      Network Printing
      Subset of commands (See Section 8.0 for a list of what is not included.)
      User's Guide
      Use of Application Administration to control access to function in the package

  The following features from IBM i Access for Windows are not included in this package. 
  The platform-independent IBM i Access Client Solution package includes a replacement
  for these features:
    5250 Display and Printer Emulation
    Data Transfer
    Data Transfer Excel Add-in
    Operations Console
  
  The following features from IBM i Access for Windows are not included in this package. 
  IBM Navigator for i includes a replacement for these features:
    System i Navigator
    AFP Workbench Viewer

  Incoming Remote Command is not included.  The replacement is to use Microsoft's
  Remote Desktop Services.

  Toolbox for Java is also not included.  Use the following website for download
  information:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Other features from IBM i Access for Windows not included in this package are:
    SCS Printer Driver
    Java Programmer's Tools for System i Navigator plug-ins
    Directory Update
    Lotus 123 File Format Support
    Check Service Level

  Because the content of this package also ships with 7.1 IBM i Access for Windows, 
  the documentation and versioning often reflects 7.1 IBM i Access for Windows in the 
  User's Guide, Programmer's Toolkit, help text and messages but is also 
  applicable to IBM i Access Client Solutions - Windows Application Package.


-------------------------------------------------------------------

2.0 Location of Information Sources

-------------------------------------------------------------------
  
  - Changes to IBM i Access Client Solutions including supported operating systems, 
    updates, restrictions, significant known problems, new information and more will 
    be published on the IBM i Access product website:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - The User's Guide that is installed with this package contains information on
    using the product, some tips and techniques, messages, and troubleshooting 
    information.

  - Technical references to the OLE DB provider and the .NET Data Provider are installed
    when the Headers, Libraries and Documentation feature is installed.  You can
    find the technical references in the Programmer's Toolkit folder.

  - The IBM i Information Center provides a collection of topics designed for IBM i
    professionals who need access to technical information:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - At the time of this publication, the IBM i Information Center did not include topics 
    about IBM i Access Client Solutions.  However, much of the information under IBM i Access
    for Windows is applicable to this package of IBM i Access Client Solutions, including 
    the installation, administration and programming topics:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks contains articles, tutorials, and technical resources for
    IBM i users:

    https://www.ibm.com/developerworks/ibmi

  - The IBM i website offers the latest IBM i news, as well as product information, a reference
    library, education roadmaps, and more:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Installation Information
-------------------------------------------------------------------



3.1 Supported Windows Operating Systems
---------------------------------------

  This package can be installed on the following Microsoft Windows operating 
  systems:

   - Windows Server 2022 Standard, Windows Server 2022 Datacenter

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 11 Pro, Windows 11 Enterprise

   - Windows 10 Pro, Windows 10 Enterprise

   The following restrictions apply:
 
     a) Home editions are not supported.
     b) You must use Windows service pack levels that Microsoft supports.
     c) Support will discontinue on the date that Microsoft drops support.
     d) Installation is not supported on Itanium hardware.
     e) Use Microsoft Windows hardware and memory recommendations. Include 
        an additional 256 MB of memory for IBM i Access Client Solution
        functions.
     f) The product cannot be installed when upgrading to a different 
        Windows operating system.  Follow these steps:
          1.  Save configuration data.
          2.  Uninstall the product.
          3.  Upgrade the Windows operating system.
          4.  Install the product.
          5.  Restore the configuration data.


3.2 Installation Considerations
--------------------------------------------------

  - Administrative authority and privileges are required to run the install.
  
  - Only per-machine installations are supported.  Per-user installations
    are not supported.

  - Windows Installer 4.5 is required.  This Microsoft software component
    is installed during the install if it is not already present on the
    system.  You can install this before the install by downloading it 
    from the Microsoft web site:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Upgrading from IBM i Access for Windows
-------------------------------------------

  -  Upgrading from IBM i Access for Windows is not supported.  You must
     remove IBM i Access for Windows before you install this package.  

  -  Refer to Section 1.0 for the list of features that are not included.  If 
     you want to continue using features in IBM i Access for Windows not
     included in this package, do not install this package and continue to use
     the latest service pack of 7.1 IBM i Access for Windows.

  -  When IBM i Access for Windows is uninstalled, the existing system 
     configuration will be deleted.  To preserve the existing system 
     configuration, you will need to save the configuration before uninstalling
     IBM i Access for Windows and then restore the configuration after IBM i 
     Access Client Solutions Windows Application Package has been installed.

     Here are the detailed steps for saving and restoring your configuration:
     1.  Use the CWBBACK command to backup the IBM i Access for Windows
         configuration.
             cwbback <filename.rs> /u
         For example:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         This example assumes the folder C:\Users\IBM_ADMIN\Backup already exists.

         The above command will create two files in that folder:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Make sure these two files were created before going to the next step.

         NOTE:
         If the above two files did not get created, then you do not have a saved
         configuration.  Try running the command as an elevated administrator.
         One way to do that is to start a command prompt as follows:
             Start->All Programs->Accessories->Command Prompt
         But instead of using the left-click on Command Prompt, use a right-click and
         select the option to "Run as administrator".
         Run the above cwbback command using this command prompt.
         Make sure the above two files were created before going to the next step.

     2.  Uninstall IBM i Access for Windows.
     3.  Reboot.
     4.  Install IBM i Access Client Solutions Windows Application Package.
     5.  Reboot.
     6.  Use the CWBREST command to restore the configuration that was saved with
         the CWBBACK command.
             cwbrest <filename.rs> /c
         For example:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         If you were required to follow the instructions in the NOTE in step 1, you
         will also need to run the cwbrest command from an elevated administrator
         command prompt.

  -  There are a couple ways you can verify your Windows configuration before and
     after the above steps:
     1. Check the Windows registry.  The system configurations are stored at:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	To view the contents of the Windows registry at that location, enter this command:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        If you have an environment named something other than the default
        "My Connections", make the appropriate substitution in the above path.

     2. If you have the platform-independent version of IBM i Access Client Solutions on the same
        PC, from the main GUI panel you can select:
            File->Copy Connections
        The right side will show "IBM i Access (Windows)".  This is the configuration used for
        both IBM i Access for Windows and for IBM i Access Client Solutions Windows Application
        Package.


3.4 Running the Install
-----------------------
  
  - Run setup.exe in the installation image to start the install.  (The command
    cwblaunch.exe is not shipped with this product.)
   
      NOTE:  Direct invocation of Microsoft Installer (MSI) files is not
             recommended because setup.exe uses setup.ini for a list of command
             line options to be used and to update the Windows Installer 
             version if needed.
    
  - It is recommended that you use the default destination folder.  However, 
    if you change the folder:
     
     a) Do not select the root directory of a drive.
     b) Do not select a directory that already contains files not
        related to this product.
     c) Do not select a network drive.  Installing to a network drive 
        is not supported.


3.5 Action Required After Installing Printer Driver
---------------------------------------------------

  If you install the APF printer driver, you must take action before using the 
  printer driver.  This is needed because the printer driver cannot be automatically 
  added or updated during the install since the printer driver is not digitally 
  signed by Microsoft.  

  During the install, the printer driver files are copied to a subdirectory named 
  CWBAFP under the destination path that is chosen.  Assuming that you installed 
  to the default destination path, the path would be:

  c:\Program Files\IBM\Client Access\CWBAFP directory 

  Use Microsoft's directions in their help text to add or update the printer driver.
  When prompted, specify the path to CWBAFP. 

  If you are installing on a PC that has upgraded the IBM i Access for Windows product 
  over multiple releases, some old information may possibly be displayed when you configure 
  the printer driver.  To remove the obsolete information from .inf files, do the following 
  after you have completed the install:

    a) Open a command prompt window.
    b) Change the directory to your installation directory. The default installation 
       directory is c:\Program Files\IBM\Client Access.
    c) Type "cwbrminf" and press Enter. 


3.6 64-bit hardware installation considerations
-----------------------------------------------

  When installed on a supported 64-bit Windows operating system:
  
  -  Both the 32-bit version and the 64-bit version are installed for ODBC, OLE DB, 
     ActiveX, and Secure Sockets Layer (SSL).  

  -  The IBM i Access for Windows .NET provider runs from both 32-bit and from 64-bit
     applications, dependent upon the application calling the provider.

  -  Only one version of the AFP Printer Driver is installed.  The 64-bit version 
     is installed on 64-bit systems and the 32-bit version is installed on 32-bit systems.


3.7 Installation logs 
---------------------

  Two logs are created during the installation. One of the logs is specific to XJ1 
  and contains the product's custom action information.  This log is named "xe1instlog.txt" 
  and is always created in the user's temp directory.

  The other log is the Microsoft MSI log that contains information about 
  MSI events, sequences, and properties.  By default, this log is named 
  "xe1instlogmsi.txt" and is created in the user's temp directory.   You can change 
  this log by editing setup.ini in the installation image.  Go to the [Startup]  
  keyword, find, and edit this entry: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - To prevent the creation of the log, remove the entry
    - To change the location and name of the log, change the path and file name
    - To change the content of the log, change the /l* to a different option(s) as 
      described by Microsoft's MSDN Windows Installer Command Line Options
      at this location 

      http://msdn.microsoft.com/default.aspx   

  The default command line information in setup.ini can by overridden by starting 
  setup.exe at the command prompt with command line options.



-------------------------------------------------------------------

4.0 IBM.Data.DB2.iSeries .NET Provider requirements 

-------------------------------------------------------------------

  - The IBM i Access for Windows .NET Provider (IBM.Data.DB2.iSeries)
    requires that Microsoft .NET Framework Version 2.0 or later be installed on your 
    system.  Most PCs running supported Microsoft operating systems already have 
    the required .NET Framework installed.  The .NET Framework can be downloaded 
    from the following Microsoft Web site: 

    http://www.microsoft.com/net 

  - To avoid breaking .NET applications that were written to the Access for Windows 5.3 
    or 5.4 .NET provider interface, runtime requests for the 10.0.0.0 version of the
    .NET provider must be redirected to the 12.0.0.0 version.  See the 
    "Incompatible changes from 5.3 and 5.4" topic in the IBM DB2 for i
    .NET Provider Technical Reference for instructions on using an app.config file, 
    a web.config file, or a machine.config file and for information on selecting an 
    appropiate compiler for redirecting existing applications.

    Alternatively, the application can be recompiled using a newer compiler to target 
    the 12.0.0.0 version of the .NET provider included in the IBM i Access for Windows 
    7.1 release.

  - For complete information and a list of incompatible changes, install the  Headers, 
    Libraries, and Documentation feature, and then display the .NET Provider Technical 
    Reference. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser or Microsoft XML Core Services

-------------------------------------------------------------------

  When using the IBM i Access for Windows Data Transfer ActiveX automation objects to 
  transfer files to and from Microsoft Excel XML format (supported by Excel 2003 and 
  Excel XP), additional software must be installed on your PC. This feature requires that 
  the Microsoft XML Parser 3.0 or beyond, also known as the Microsoft XML Core Services, 
  is installed on your personal computer. The XML Parser is included in many Microsoft
  products.  To determine if the XML Parser support is installed on your PC, refer to
  Microsoft KB article 278674.  This article can be found at the Microsoft web site at:

  http://support.microsoft.com/kb/278674

  If the Microsoft XML Parser 3.0 or later is not found, you will need to access the
  Microsoft web for instructions on downloading and installing the XML Parser before 
  you can use the Data Transfer XML support.  Refer to Microsoft KB article 324460
  for information about installing the XML Parser.  This article can be found at:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Advanced Installation Information

-------------------------------------------------------------------

  You can use most of the information on modifying the user interface level, using
  command line parameters, controlling other installation behavior and deployment methods
  in the "Setting up the PC" topic in the IBM i Information Center for 
  IBM i Access for Windows.  Differences are described in this section.


6.1 Licensed Product Information
----------------------------------
  
  5733XJ1 is not packaged as a Licensed Product to be installed on the IBM i operating system.
  It is only available as PC media. You can copy it to the IBM i at a location that is 
  available to your users, if you desire.
  

6.2 Language Files in the Installation Image
--------------------------------------------
  
  The language install files are no longer separated into different MRI29xx directories
  in the installation image. Instead there are separate cab files for each language.  You 
  cannot remove these cab files from the image.


6.3 Install Features
--------------------

  Some install features in IBM i Access for Windows depended on other install features to be
  installed.  This restriction is not applicable to this package.

  The following install features are required to be installed:
    req (Required Programs)
    langacs, amri2924 (English)

  All other install features are installed by default but you can change the setting.

  Languages are now install features, just like Required Programs, ODBC, etc.  Because
  languages are install features, you can control which languages are installed using 
  the same methods used to control any install feature.  The install feature names for the
  languages are amri29xx.  


6.4 Command line options
------------------------

  The default command line options are specified in the setup.ini file included in the
  installation image.  These options will be ignored if you invoke setup.exe from the 
  command line with any options specified.  

  If you are using a transform on the command line, the command line values in setup.ini 
  will be ignored because the transform is an option.  You will need to include other options
  on the command line to such as the logging information.

  See Section 3.7 Installation logs for more information.


6.5 Public Properties
---------------------

  Some of the IBM i Access for Windows public properties are applicable to this package.  The
  usage has some changes from the usage in IBM i Access for Windows, as described here:

  CWBINSTALLTYPE   This property is only used on a first time installation.  The only values
                   are Typical and Custom.  The default is Typical.
                   Example:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   The default primary language is the locale of your PC.  This property allows 
                   you to specify a different primary language. The value to use is MRI29xx. 
                   Example:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   The usage of this property is the same as IBM i Access for Windows.  It allows
                   you to upgrade the SSL files during an upgrade.  If the configuration files for 
                   SSL are found on the target PC, the files will be updated with the latest 
                   certificates.  The values are Yes and No.  The default is Yes.
                   Example:  setup /vCWBUPGSSLFILES=NO

  The common Windows Installer properties listed in the IBM i Access for Windows Information Center 
  topic remain applicable:  ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  There is a restriction on using the REBOOT Windows Installer property with IBM i Access
  for Windows.  This restriction is not applicable to this package.
  

6.6 Burning Administrative Images to CD or DVD 
----------------------------------------------

  Due to issues with how some CD- and DVD-burning software handle long file names, burning
  an administrative image to a CD or DVD is not recommended. If you experience problems
  installing from a CD or DVD that contains an administrative image of IBM i Access for
  Windows, copy the image to a directory on the local hard drive and run setup.exe from the
  local copy.

-------------------------------------------------------------------
7.0 Policy Information
-------------------------------------------------------------------

  The same policy file is used for both this package and IBM i Access for Windows. That 
  means that some of those policies are not applicable when used for this package since
  some of the function in IBM i Access for Windows does not exist in this package.

-------------------------------------------------------------------

8.0 Commands
-------------------------------------------------------------------

  The commands in IBM i Access for Windows that are not included in this package: 
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[END OF DOCUMENT]
